package com.example.weahter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
