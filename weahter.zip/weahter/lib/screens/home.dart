import 'dart:convert';
import 'package:weahter/weather location/location.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'searchpage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class Weather extends StatefulWidget {
  @override
  _WeatherState createState() => _WeatherState();
}

class _WeatherState extends State<Weather> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home:navigation()
    );
  }
}
class navigation extends StatefulWidget {
  const navigation({Key? key}) : super(key: key);

  @override
  _navigationState createState() => _navigationState();
}

class _navigationState extends State<navigation> {
  getLocation get = getLocation();
   String? cityName;


  @override
  void city() async {
    setState(() {
      get.getlocation();
    });

  }
  void initState(){
    super.initState();
     city();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Container(child:
          IconButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>SearchBar()
            ),
            );
          }, splashRadius: 20.0, icon: Icon(Icons.search,),
          ),
          ),
          IconButton(onPressed: ()async{
            city();

          },splashRadius: 20.0,tooltip:'get the current location weather', icon: Icon(Icons.navigation
          ),
          ),

        ],
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(FontAwesomeIcons.cloud,),
            SizedBox(
              width: 10.0,
            ),
            Text('Weather',
              style:GoogleFonts.mcLaren(textStyle: TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.w900,
                fontSize: 32.0,
              ),
              ),
            ),

          ],
        ),
        backgroundColor: Colors.black,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(child:Container(child: Center(
            child: Text('Temperature :-'+ get.temp.toString()+'º',
              style: TextStyle(
                color: Colors.red,
                fontSize: 22.0,
              ),
              textAlign: TextAlign.center,

            ),
          ),
            margin: EdgeInsets.all(30.0),
            decoration: BoxDecoration (
              color: Colors.black,
              borderRadius: BorderRadius.circular(35.0),
            ),
          ),
          ),
          Expanded(child:Container(child: Center(
            child: Text('cityname :- '+get.cityName.toString(),
              style:GoogleFonts.lato(textStyle: TextStyle(
                color: Colors.red,
                fontSize: 22.0,
              ),
              ),
              textAlign: TextAlign.center,
            ),
          ),
            margin: EdgeInsets.all(30.0),
            decoration: BoxDecoration (
              color: Colors.black,
              borderRadius: BorderRadius.circular(25.0),
            ),
          ),
          ),
        ],),
    );
  }
}
