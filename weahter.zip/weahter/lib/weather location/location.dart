import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class getLocation
{
   String? cityName;
   int? temp;
  static String apikey = '1e53feb8e2102b16f677f67f95d2acb0';
  Future getlocation()async
  {
    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,timeLimit: Duration(seconds:1));
    //
    var lati = position.latitude;
    var longi = position.longitude;
    // String url = await 'https://api.openweathermap.org/data/2.5/weather?`lat=$lati&lon=$longi&appid=$apikey&units=metric';
    // http.Response response = await http.get(Uri.parse(url));
    // String res = response.toString();
    // String data = response.body;
    // return data;

    getWeather(position.latitude, position.longitude);
  }

  Future getWeather(double lati,double longi)async{
    // print(lati+ longi);
    String url = await 'https://api.openweathermap.org/data/2.5/weather?lat=$lati&lon=$longi&appid=$apikey&units=metric';
    http.Response response = await http.get(Uri.parse(url));
    // String res = response.toString();
    String data = response.body;
    // print(data);
    cityName = await jsonDecode(data)['name'];

    double tem =  jsonDecode(data)['main']['temp'];
    temp =await tem.toInt();
    print(temp);
    print(cityName);
    // return { temp,cityName};
  }
  Future getTemperature()async
  {
    Future.delayed(Duration(seconds: 1),(){
      // print(temp);
      return  temp;
    });

  }
  Future getCity()async
  {
    String? city;
   await Future.delayed(Duration(seconds:1),(){
     // city = cityName;
     return cityName;
   });
    // print('hello $city');

  }
}